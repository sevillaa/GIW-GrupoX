"""Punto de entrada para empaquetar rest_server/ como ejecutable con PyInstaller.

No hace falta para desarrollo normal (ahí se usa `python -m rest_server.main`,
ver CLAUDE.md); este script solo existe porque PyInstaller necesita un script
de nivel superior, no un módulo de paquete ejecutado con `-m`.

Compilar (repetir en cada sistema operativo donde se quiera distribuir; ver
CLAUDE.md para las instrucciones completas):
    pyinstaller --onefile --name rest_server_giw iniciar_servidor.py
"""

import uvicorn

from rest_server.main import app

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)
