# Cómo poner en marcha el simulador (Práctica 6 GIW)

Esta carpeta contiene el **Simulador de servicio REST**: un pequeño programa que hace de servidor y
que necesitas tener **arrancado y en marcha** mientras trabajas en la Práctica 6. No hace falta
entender cómo funciona por dentro, solo saber ponerlo en marcha y dejarlo corriendo.

No necesitas abrir ni mirar ningún fichero de esta carpeta salvo este. Si algún paso no te funciona
tal cual, consulta a el profesor.


## Paso 1: abrir una terminal en esta carpeta

Todos los comandos de este documento se escriben en una terminal, y tiene que estar abierta
**dentro de esta misma carpeta** (la que contiene este fichero).

- **Windows**: abre esta carpeta con el Explorador de archivos, haz clic en la barra de la ruta
  (arriba, donde pone la dirección de la carpeta), escribe `cmd` y pulsa Enter. Se abrirá una
  terminal ya situada en esta carpeta.
- **macOS**: abre la app "Terminal" (búscala con Spotlight, `Cmd+Espacio` y escribe "Terminal").
  Escribe `cd ` (con un espacio detrás, sin pulsar Enter todavía), arrastra esta carpeta desde el
  Finder hasta la ventana de Terminal (se rellena la ruta sola), y pulsa Enter.
- **Linux**: casi todos los gestores de archivos permiten clic derecho dentro de la carpeta →
  "Abrir terminal aquí" o similar. Si no, abre una terminal y usa `cd` para llegar hasta esta carpeta.

## Paso 2: instalar lo necesario (solo la primera vez)

En esa terminal:

```
pip install -r requirements.txt
```

Si `pip` no funciona, prueba `pip3 install -r requirements.txt`. Esto descarga e instala las
librerías que el simulador necesita para funcionar; tarda solo unos segundos y solo hace falta
hacerlo una vez (no hace falta repetirlo cada vez que arranques el simulador).

## Paso 3: arrancar el simulador

En la misma terminal:

```
python iniciar_servidor.py
```

(o `python3 iniciar_servidor.py` si `python` no funcionó antes).

Si todo va bien, verás algo como:

```
INFO:     Uvicorn running on http://127.0.0.1:8000 (Press CTRL+C to quit)
```

**Deja esa ventana de terminal abierta** mientras trabajes en la práctica — si la cierras, el
simulador se para. No hace falta hacer nada más en esa ventana; puedes abrir otra terminal aparte
para trabajar en tu código de la práctica mientras esta sigue corriendo.

### Cómo comprobar que está funcionando

Abre un navegador y entra en:

- `http://127.0.0.1:8000/` — página de bienvenida.
- `http://127.0.0.1:8000/docs` — documentación de lo que ofrece el simulador.

Si esas páginas cargan, el simulador está funcionando correctamente.

### Cómo pararlo

Con la ventana de terminal donde está corriendo seleccionada, pulsa `Ctrl+C`. También puedes
simplemente cerrar esa ventana.

---

## Dónde se guardan los datos y el token

El simulador guarda todo lo que crees (usuarios, tareas...) en un fichero llamado `tokens.json`,
dentro de una carpeta `data/` que se crea sola junto al programa la primera vez que lo arrancas. No
necesitas tocar ese fichero ni esa carpeta para nada.

Ya viene preparado con un token de ejemplo, listo para usar sin configurar nada:

```
local-dev-token-0001
```

Ese es el valor que debe tener el fichero `api_token.txt` de tu práctica (el que lee tu código con
`get_token()`). Los datos se guardan entre un arranque y otro: si paras el simulador y lo vuelves a
arrancar, lo que hubieras creado sigue ahí.

---

## Problemas típicos

- **"Address already in use" / "puerto en uso"**: significa que el simulador ya está corriendo en
  otra ventana (puede que se te olvidara que lo tenías abierto). Busca esa ventana en vez de abrir
  una nueva, o ciérrala antes de volver a arrancarlo.
- **En Mac, al arrancarlo aparece un aviso de seguridad ("no se puede verificar el desarrollador" o
  similar) y no arranca**: es normal la primera vez, porque el programa no está firmado por Apple.
  Solución: en el Finder, haz clic derecho sobre esta carpeta → "Abrir" (en vez de doble clic) y
  confirma; o, si eso no aparece, abre una terminal en esta carpeta y ejecuta:
  ```
  xattr -dr com.apple.quarantine .
  ```
  y vuelve a intentarlo.
- **`python` (o `pip`) no se reconoce como comando**: prueba con `python3`/`pip3` en su lugar. Si
  tampoco funciona, es que Python no está instalado o no se añadió al PATH durante la instalación
  (ver la sección "Antes de empezar" más arriba).
- **Se te olvida que lo tienes que dejar arrancado**: si tu código de la práctica falla con errores
  de conexión, lo primero que hay que comprobar es que esta ventana sigue abierta y sigue mostrando
  el mensaje "Uvicorn running".

Si nada de esto soluciona el problema, consulta a el profesor.
